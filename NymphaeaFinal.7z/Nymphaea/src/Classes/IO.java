package Classes;

import java.io.*;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class IO {   
    // <editor-fold defaultstate="collapsed" desc="Variaveis.">
    
    //Variaveis para guardar informaçao no ficheiro 
    private String defaultPath;
    static String diretorio = System.getProperty("user.dir");
    private static String historySavePath = diretorio + "/CSV/historico.csv";
    private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    private Date currentDate = new Date();
    private String lastSave;
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Construtor.">
    public IO(String path) {
        this.defaultPath = path;
        
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Gravar sessão.">
    public void guardarEstado(String info, int totalLines, String ficheiroModificado, boolean Append) {
        // <editor-fold defaultstate="collapsed" desc="Gravar ficheiro CSV com objectos.">
        BufferedWriter fos = null;
        try {
            //Abrir o ficheiro
            File ficheiroOutput = new File(this.defaultPath);
            fos = new BufferedWriter(new FileWriter(ficheiroOutput,Append));
            if (!ficheiroOutput.exists()) {
                ficheiroOutput.createNewFile();
            }
            fos.write(info);
            fos.flush();
            fos.close();
            this.lastSave = dateFormat.format(currentDate);
                        
        }
        catch (IOException e) {
            e.printStackTrace();
        }  
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar ficheiro CSV de histórico de gravação.">
        BufferedWriter historicoFos = null;
        try {
            //Abrir o ficheiro
            File historicoOutput = new File(this.historySavePath);
            historicoFos = new BufferedWriter(new FileWriter(historicoOutput, true));
            if (!historicoOutput.exists()) {
                historicoOutput.createNewFile();
            }
            String novaEntrada = ficheiroModificado + ";" + totalLines + ";" 
                    + this.lastSave + "\n";
            historicoFos.write(novaEntrada);
            historicoFos.flush();
            historicoFos.close();               
        }
        catch (IOException e) {
            e.printStackTrace();
        }  
        // </editor-fold>
        
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Dar load da sessão.">
    public List<String> carregarEstado() { 
        List<String> toLoad = new java.util.ArrayList<String>();
        BufferedReader fis = null;
        try {
            int a = 0;
            int b = 0;
            File ficheiroInput = new File(this.defaultPath);
            fis = new BufferedReader(new FileReader(ficheiroInput));
            toLoad.add("");
            while (a != -1) {
                a = fis.read();
                if (a!=-1) {
                    if (a==10) {
                        b += 1;
                        toLoad.add("");
                    }
                    else {
                        String temp = String.valueOf((char)a);
                        //toLoad.add(b,toLoad.get(b).concat(temp));
                        String temp2 = toLoad.get(b) + temp;
                        
                        toLoad.set(b, temp2);
                    }
                }
            }
            fis.close();
            this.lastSave = dateFormat.format(currentDate);
            return toLoad;               
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }   
    }
    // </editor-fold>
}