package Classes;

public class Contabilidade {
    // <editor-fold defaultstate="collapsed" desc="Variaveis.">
    private static float lucro = 0;
    private static float totalGasto = 0;
    private static float netWorth = 0;
    private static int stockVendido = 0;
    private static int stockComprado = 0;
    private static float totalSalarios = 0;
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Construtores.">
    public Contabilidade(int lucro, int totalGasto, int netWorth, int totalSalarios){
        this.lucro = lucro;
        this.totalGasto = totalGasto;
        this.netWorth = netWorth;
        this.totalSalarios = totalSalarios;
    }
    
    //Construtor que utiliza um array para guardar em ficheiro
    public Contabilidade(String[] arr){
        this.lucro = Float.parseFloat(arr[0]);
        this.totalGasto = Float.parseFloat(arr[1]);
        this.netWorth = Float.parseFloat(arr[2]);
        this.totalSalarios = Float.parseFloat(arr[3].replace("\n", "").replace("\r", ""));
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Métodos de venda e compra.">
    //Método quando executado venda ao cliente
    public void actionVenda(float valor, int quant) {
        float valorTotal = valor * quant;
        this.lucro += valorTotal;
        this.netWorth += valorTotal;
        this.stockVendido += quant;
    }
    
    //Método quando executado compra ao fornecedor
    public void actionCompra(float valor, int quant) {
        float valorTotal = valor * quant;
        this.totalGasto += valorTotal;
        this.netWorth -= valorTotal;
        this.stockComprado += quant;   
    }
    
    public void updateSalario(int salarioTotal) {
        this.totalSalarios = salarioTotal;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Gets.">
    public float getLucro() {
        return this.lucro;
    }
    
    public float getTotalGasto() {
        return this.totalGasto;
    }
    
    public float getNetWorth() {
        return this.netWorth;
    }
    
    public int getStockVendido() {
        return this.stockVendido;
    }
    
    public int getStockComprado() {
        return this.stockComprado;
    }
    
    public float getTotalSalarios() {
        return this.totalSalarios;
    }
    // </editor-fold>
    
}