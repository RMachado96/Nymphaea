package Visual;
import Classes.IO;
import Classes.Medicamentos;
import Classes.Pessoa;
import Classes.Contabilidade;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.table.DefaultTableModel;

//
//
//THIS IS THE MAIN BUILD
//
//
public class Gestao extends javax.swing.JFrame{

    public Gestao(){
        initComponents();
        this.setLocationRelativeTo(null);
        
        //todos os botoes/tabelas/etc tem de ser postos a .setVisible(false) ao inicio do programa
        jBCriarEmp.setVisible(false); 
        jBCancEmp.setVisible(false);
        jTextField1.setVisible(false);
        jTextField2.setVisible(false);
        jTextField4.setVisible(false);
        jComboBox1.setVisible(false);
        jComboBox2.setVisible(false);
        jTable2.setVisible(false);
        jStock.setVisible(false);
        
        // <editor-fold defaultstate="collapsed" desc="Carregar a lista de Empregados">
        int totalSalarios = 0;
        String diretorio = System.getProperty("user.dir");
        
        IO ficheiroEmpregados = new IO(diretorio + "/CSV/empregados.csv");       
        List<String> carregarEmpregados = ficheiroEmpregados.carregarEstado();
        List<Pessoa> listaPessoa = new java.util.ArrayList<Pessoa>();
       
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        try{
            for(int i = 0; i < carregarEmpregados.size(); i++){
                String[] temp = carregarEmpregados.get(i).split(";");
                listaPessoa.add(new Pessoa(temp));
                model.addRow(new Object[]{listaPessoa.get(i).getID(), 
                    listaPessoa.get(i).getPnome() + " " + listaPessoa.get(i).getUnome(), 
                    listaPessoa.get(i).getIdade(),
                    listaPessoa.get(i).getRank(),
                    listaPessoa.get(i).getPosicao(), 
                    listaPessoa.get(i).getSalario(),
                    listaPessoa.get(i).getEstado()});
                totalSalarios += listaPessoa.get(i).getSalario();
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar informação para dar update dos salarios">
        IO ficheiroContabilidade = new IO(diretorio + "/CSV/contabilidade.csv");       
        //Lista auxiliar para carregar dados na tabela        
        List<String> carregarContabilidade = ficheiroContabilidade.carregarEstado();
        List<Contabilidade> listaContabilidade = new java.util.ArrayList<Contabilidade>();
        
        try{
            for(int i = 0; i < carregarContabilidade.size() - 1; i++){
                String[] temp = carregarContabilidade.get(i).split(";");
                listaContabilidade.add(new Contabilidade(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
        
        listaContabilidade.get(0).updateSalario(totalSalarios);
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar informaçao dos salarios atualizada">
        IO gravarContabilidade = new IO(diretorio + "/CSV/contabilidade.csv");
        
        try{
            String info = listaContabilidade.get(0).getLucro()
                    + ";" + listaContabilidade.get(0).getTotalGasto()
                    + ";" + listaContabilidade.get(0).getNetWorth()
                    + ";" + listaContabilidade.get(0).getTotalSalarios()
                    + "\n";
            gravarContabilidade.guardarEstado(info, 1, "contabilidade.csv", false);
        }
        catch(Exception tR){System.out.println(tR);}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar informação da contabilidade">
        IO ficheiroContabilidade2 = new IO(diretorio + "/CSV/contabilidade.csv");
        //Lista auxiliar para carregar salários dos funcionários  
        List<String> carregarContabilidade2 = ficheiroContabilidade2.carregarEstado();
        List<Contabilidade> listaContabilidade2 = new java.util.ArrayList<Contabilidade>();
        
        try{
            for(int i = 0; i < carregarContabilidade2.size() - 1; i++){
                String[] temp = carregarContabilidade2.get(i).split(";");
                listaContabilidade2.add(new Contabilidade(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
        
        jTextField6.setText(String.valueOf(listaContabilidade2.get(0).getNetWorth()));
        jTextField7.setText(String.valueOf(listaContabilidade2.get(0).getTotalGasto()));
        jTextField8.setText(String.valueOf(listaContabilidade2.get(0).getTotalSalarios()));
        jTextField9.setText(String.valueOf(listaContabilidade2.get(0).getLucro()));
        // </editor-fold>  
        
        // <editor-fold defaultstate="collapsed" desc="Carregar Stock inicial para as tabelas.">
        IO ficheiroMeds = new IO(diretorio + "/CSV/stock.csv");       
        List<String> carregarMedicamentos = ficheiroMeds.carregarEstado();
        DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel();
        try{
            for(int i = 0; i < carregarMedicamentos.size(); i++){
                String[] temp = carregarMedicamentos.get(i).split(";");
                model2.addRow(new Object[]{temp[1], temp[2], temp[4]});  
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
    }

    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Core = new javax.swing.JTabbedPane();
        Pessoal = new javax.swing.JPanel();
        jLista = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton10 = new javax.swing.JButton();
        jCriar = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jBCriarEmp = new javax.swing.JButton();
        jBCancEmp = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jBPesListar = new javax.swing.JButton();
        jBPesCriar = new javax.swing.JButton();
        Contabilidade = new javax.swing.JPanel();
        jTextField6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        Itens = new javax.swing.JPanel();
        jBStock = new javax.swing.JButton();
        jNProduto = new javax.swing.JPanel();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jBInvConf = new javax.swing.JButton();
        jBInvCanc = new javax.swing.JButton();
        jStock = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton11 = new javax.swing.JButton();
        jTextField14 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jBNProduto = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setResizable(false);

        Core.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                CoreFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                CoreFocusLost(evt);
            }
        });

        Pessoal.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                PessoalFocusGained(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Idade", "Rank", "Posição", "Salário", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
        }

        jButton10.setText("Guardar Alterações");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jListaLayout = new javax.swing.GroupLayout(jLista);
        jLista.setLayout(jListaLayout);
        jListaLayout.setHorizontalGroup(
            jListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jListaLayout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(110, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jListaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton10)
                .addGap(248, 248, 248))
        );
        jListaLayout.setVerticalGroup(
            jListaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jListaLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jButton10)
                .addContainerGap(195, Short.MAX_VALUE))
        );

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Primeiro nome");

        jLabel2.setText("Ultimo nome");

        jLabel3.setText("Posição");

        jLabel4.setText("Idade");

        jLabel5.setText("Rank");

        jBCriarEmp.setText("Criar novo empregado");
        jBCriarEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCriarEmpActionPerformed(evt);
            }
        });

        jBCancEmp.setText("Cancelar");
        jBCancEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBCancEmpActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ativo", "Inativo" }));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Farmacêutico - Nível 1", "Farmacêutico - Nível 2", "Farmacêutico - Nível 3", "Gerente"}));

        javax.swing.GroupLayout jCriarLayout = new javax.swing.GroupLayout(jCriar);
        jCriar.setLayout(jCriarLayout);
        jCriarLayout.setHorizontalGroup(
            jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jCriarLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING))
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jCriarLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox2, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jCriarLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jCriarLayout.createSequentialGroup()
                                .addComponent(jBCriarEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(jBCancEmp, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)))))
                .addContainerGap(126, Short.MAX_VALUE))
        );
        jCriarLayout.setVerticalGroup(
            jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jCriarLayout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jCriarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBCancEmp)
                    .addComponent(jBCriarEmp))
                .addContainerGap(361, Short.MAX_VALUE))
        );

        jBPesListar.setText("Listar");
        jBPesListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPesListarActionPerformed(evt);
            }
        });

        jBPesCriar.setText("Criar");
        jBPesCriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPesCriarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PessoalLayout = new javax.swing.GroupLayout(Pessoal);
        Pessoal.setLayout(PessoalLayout);
        PessoalLayout.setHorizontalGroup(
            PessoalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PessoalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PessoalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBPesListar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBPesCriar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addComponent(jLista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PessoalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PessoalLayout.createSequentialGroup()
                    .addGap(0, 136, Short.MAX_VALUE)
                    .addComponent(jCriar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        PessoalLayout.setVerticalGroup(
            PessoalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLista, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PessoalLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jBPesListar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBPesCriar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(PessoalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jCriar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Core.addTab("Pessoal", Pessoal);

        jTextField6.setEditable(false);

        jLabel6.setText("Saldo atual");

        jTextField7.setEditable(false);

        jLabel7.setText("Total gasto");

        jTextField8.setEditable(false);

        jLabel8.setText("Salários");

        jTextField9.setEditable(false);

        jLabel9.setText("Lucro");

        jLabel15.setText("€");

        jLabel16.setText("€");

        jLabel17.setText("€");

        jLabel18.setText("€");

        javax.swing.GroupLayout ContabilidadeLayout = new javax.swing.GroupLayout(Contabilidade);
        Contabilidade.setLayout(ContabilidadeLayout);
        ContabilidadeLayout.setHorizontalGroup(
            ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContabilidadeLayout.createSequentialGroup()
                .addGap(271, 271, 271)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(374, Short.MAX_VALUE))
        );
        ContabilidadeLayout.setVerticalGroup(
            ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContabilidadeLayout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel15))
                .addGap(18, 18, 18)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(ContabilidadeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel18))
                .addContainerGap(310, Short.MAX_VALUE))
        );

        Core.addTab("Contabilidade", Contabilidade);

        jBStock.setText("Stock");
        jBStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBStockActionPerformed(evt);
            }
        });

        jLabel10.setText("Nome do produto");

        jLabel11.setText("Descrição do produto");

        jLabel12.setText("Preço");

        jLabel13.setText("Quantidade");

        jBInvConf.setText("Confirmar");
        jBInvConf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBInvConfActionPerformed(evt);
            }
        });

        jBInvCanc.setText("Cancelar");

        javax.swing.GroupLayout jNProdutoLayout = new javax.swing.GroupLayout(jNProduto);
        jNProduto.setLayout(jNProdutoLayout);
        jNProdutoLayout.setHorizontalGroup(
            jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jNProdutoLayout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jNProdutoLayout.createSequentialGroup()
                        .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(42, 42, 42)
                        .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField10)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jNProdutoLayout.createSequentialGroup()
                        .addComponent(jBInvConf)
                        .addGap(58, 58, 58)
                        .addComponent(jBInvCanc)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jNProdutoLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(177, Short.MAX_VALUE))
        );
        jNProdutoLayout.setVerticalGroup(
            jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jNProdutoLayout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(28, 28, 28)
                .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(26, 26, 26)
                .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(111, 111, 111)
                .addGroup(jNProdutoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBInvConf)
                    .addComponent(jBInvCanc))
                .addContainerGap(204, Short.MAX_VALUE))
        );

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Descrição", "Quantidade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jButton11.setText("Comprar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel14.setText("Quantidade");

        javax.swing.GroupLayout jStockLayout = new javax.swing.GroupLayout(jStock);
        jStock.setLayout(jStockLayout);
        jStockLayout.setHorizontalGroup(
            jStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockLayout.createSequentialGroup()
                .addGroup(jStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jStockLayout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jStockLayout.createSequentialGroup()
                        .addGap(255, 255, 255)
                        .addComponent(jButton11))
                    .addGroup(jStockLayout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(80, Short.MAX_VALUE))
        );
        jStockLayout.setVerticalGroup(
            jStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addGroup(jStockLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(40, 40, 40)
                .addComponent(jButton11)
                .addGap(103, 103, 103))
        );

        jBNProduto.setText("Comprar novo produto");
        jBNProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBNProdutoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout ItensLayout = new javax.swing.GroupLayout(Itens);
        Itens.setLayout(ItensLayout);
        ItensLayout.setHorizontalGroup(
            ItensLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ItensLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(ItensLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBNProduto)
                    .addComponent(jBStock, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(ItensLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ItensLayout.createSequentialGroup()
                    .addGap(0, 243, Short.MAX_VALUE)
                    .addComponent(jNProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        ItensLayout.setVerticalGroup(
            ItensLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ItensLayout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jBNProduto)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBStock)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(ItensLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jNProduto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Core.addTab("Inventário", Itens);

        jMenu3.setText("Menu");
        jMenu3.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);

        jMenuItem1.setText("Menu Principal");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem1);

        jMenuItem2.setText("Sair");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem2);

        jMenuBar2.add(jMenu3);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Core)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Core, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //botao para menu de lista
    private void jBPesListarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jBPesListarActionPerformed
    {//GEN-HEADEREND:event_jBPesListarActionPerformed
        jLista.setVisible(true);
        jCriar.setVisible(false);
    }//GEN-LAST:event_jBPesListarActionPerformed

    //botao para menu de criaçao de pessoa
    private void jBPesCriarActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jBPesCriarActionPerformed
    {//GEN-HEADEREND:event_jBPesCriarActionPerformed
        jCriar.setVisible(true);
        jLista.setVisible(false);
        jBCriarEmp.setVisible(true);
        jBCancEmp.setVisible(true);
        jTextField1.setVisible(true);
        jTextField2.setVisible(true);
        jTextField4.setVisible(true);
        jComboBox1.setVisible(true);
        jComboBox2.setVisible(true);
        
    }//GEN-LAST:event_jBPesCriarActionPerformed

     // <editor-fold defaultstate="collapsed" desc="Botao para gravar um novo empregado">
    private void jBCriarEmpActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jBCriarEmpActionPerformed
    {//GEN-HEADEREND:event_jBCriarEmpActionPerformed
       // <editor-fold defaultstate="collapsed" desc="Variaveis e obtenção de valores">
        String diretorio = System.getProperty("user.dir");
        int idade, rank;
        idade = Integer.parseInt(jTextField4.getText());
        int sIndex2 = jComboBox2.getSelectedIndex();        
        rank = sIndex2 +1;
        int sIndex = jComboBox1.getSelectedIndex();
        String conteudo = jComboBox1.getItemAt(sIndex);
        
        IO gravarEmpregado = new IO(diretorio + "/CSV/empregados.csv");
        // </editor-fold>
        
       // <editor-fold defaultstate="collapsed" desc="Carregar o ultimo ID">
       
        IO ficheiroEmpregados2 = new IO(diretorio + "/CSV/empregados.csv");       
        List<String> carregarEmpregados2 = ficheiroEmpregados2.carregarEstado();
        List<Pessoa> listaPessoa2 = new java.util.ArrayList<Pessoa>();
        try{
            for(int i = 0; i < carregarEmpregados2.size(); i++){
                String[] temp = carregarEmpregados2.get(i).split(";");
                listaPessoa2.add(new Pessoa(temp));            
            }
        }
        catch(Exception e){System.out.println(e);}
        int maxSize = listaPessoa2.size() - 1;
        int lastID = listaPessoa2.get(maxSize).getID();
        int newID = lastID + 1;
        // </editor-fold> 
        
       // <editor-fold defaultstate="collapsed" desc="Gravaçao do novo empregado no ficheiro csv correspondente">
        try{
            Pessoa input = new Pessoa(jTextField1.getText(),jTextField2.getText(),conteudo,idade,rank,newID);
            String info =input.getPnome() + ";" + input.getUnome() + ";" 
                    + input.getEstado()
                    + ";"
                    + input.getIdade() 
                    + ";" 
                    + input.getRank()
                    + ";" 
                    + input.getID() 
                    + "\n";
            gravarEmpregado.guardarEstado(info, 1, "empregados.csv", true);
        }
        catch(Exception tR){System.out.println("Rank tem de ser entre 1 e 4");} 
        // </editor-fold>
        
       // <editor-fold defaultstate="collapsed" desc="Carregar a lista de Empregados de novo">
        IO ficheiroEmpregados = new IO(diretorio + "/CSV/empregados.csv");       
        List<String> carregarEmpregados = ficheiroEmpregados.carregarEstado();
        List<Pessoa> listaPessoa = new java.util.ArrayList<Pessoa>();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        try{
            for(int i = 0; i < carregarEmpregados.size(); i++){
                String[] temp = carregarEmpregados.get(i).split(";");
                listaPessoa.add(new Pessoa(temp));
                model.addRow(new Object[]{listaPessoa.get(i).getID(), 
                    listaPessoa.get(i).getPnome() + " " + listaPessoa.get(i).getUnome(), 
                    listaPessoa.get(i).getIdade(),
                    listaPessoa.get(i).getRank(),
                    listaPessoa.get(i).getPosicao(), 
                    listaPessoa.get(i).getSalario(),
                    listaPessoa.get(i).getEstado()});  
            }
        }
        catch(Exception e){System.out.println(e);}
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField4.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        
        // </editor-fold> 
    }//GEN-LAST:event_jBCriarEmpActionPerformed
    // </editor-fold>
    
    //menu options
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItem2ActionPerformed
    {//GEN-HEADEREND:event_jMenuItem2ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItem1ActionPerformed
    {//GEN-HEADEREND:event_jMenuItem1ActionPerformed
        this.dispose();
        new Inicio().setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jBCancEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBCancEmpActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField4.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        
    }//GEN-LAST:event_jBCancEmpActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jTextField1ActionPerformed
    {//GEN-HEADEREND:event_jTextField1ActionPerformed
       
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jBStockActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jBStockActionPerformed
    {//GEN-HEADEREND:event_jBStockActionPerformed
        jNProduto.setVisible(false);
        jStock.setVisible(true);
        jTable2.setVisible(true);
        
    }//GEN-LAST:event_jBStockActionPerformed

    private void jBNProdutoActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jBNProdutoActionPerformed
    {//GEN-HEADEREND:event_jBNProdutoActionPerformed
        jNProduto.setVisible(true);
        jStock.setVisible(false);
        jTable2.setVisible(false);
        
    }//GEN-LAST:event_jBNProdutoActionPerformed

    private void CoreFocusGained(java.awt.event.FocusEvent evt)//GEN-FIRST:event_CoreFocusGained
    {//GEN-HEADEREND:event_CoreFocusGained

    }//GEN-LAST:event_CoreFocusGained

    private void CoreFocusLost(java.awt.event.FocusEvent evt)//GEN-FIRST:event_CoreFocusLost
    {//GEN-HEADEREND:event_CoreFocusLost
    
    }//GEN-LAST:event_CoreFocusLost

    private void jBInvConfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBInvConfActionPerformed
        // <editor-fold defaultstate="collapsed" desc="Load de Stock.csv para a lista listaStock">
        String diretorio = System.getProperty("user.dir");
        IO carregarStock = new IO(diretorio + "/CSV/stock.csv");        
        List<Medicamentos> listaStock = new java.util.ArrayList<Medicamentos>();
        List<String> toLoad = carregarStock.carregarEstado();
        try{
            for(int i = 0; i < toLoad.size() - 1; i++){        
                String[] temp = toLoad.get(i).split(";");
                listaStock.add(new Medicamentos(temp));
                }
        }
        catch(Exception tR){ tR.printStackTrace();}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Criaçao do novo item">
        int ultIndex = listaStock.size() - 1;
        int ultID = listaStock.get(ultIndex).getmID();
        int proxID = ultID + 1;
        boolean naoExistente = true;
        
        for(int i = 0; i < listaStock.size() - 1; i++){
            if(naoExistente == true){
                if(!listaStock.get(i).getNomeItem().contains(jTextField10.getText())){
                    listaStock.add(new Medicamentos(jTextField10.getText(), 
                        jTextField11.getText(), 
                        Float.parseFloat(jTextField12.getText()), 
                        Integer.parseInt(jTextField13.getText()),
                        proxID));
                        naoExistente = false;
                }
            }
        }
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravacao do stock">
        
        IO gravarStock = new IO(diretorio + "/CSV/stock.csv");
        String info = "";
        int lines = 0;
        for(int i = 0; i < listaStock.size(); i++){
            String temp = listaStock.get(i).getmID() + ";" 
                        + listaStock.get(i).getNomeItem() + ";" 
                        + listaStock.get(i).getDescItem() + ";"
                        + listaStock.get(i).getValorItem() + ";"
                        + listaStock.get(i).getQuantItem() + "\n";
            info += temp;
            lines += 1;
        }
        gravarStock.guardarEstado(info, lines, "stock.csv", false);
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar informação da contabilidade">
        float preco = Float.parseFloat(jTextField12.getText());
        int finalQuant = Integer.parseInt(jTextField13.getText());
        IO ficheiroContabilidade2 = new IO(diretorio + "/CSV/contabilidade.csv");       
        List<String> carregarContabilidade2 = ficheiroContabilidade2.carregarEstado();
        List<Contabilidade> listaContabilidade2 = new java.util.ArrayList<Contabilidade>();
        try{
            for(int i = 0; i < carregarContabilidade2.size() - 1; i++){
                String[] temp = carregarContabilidade2.get(i).split(";");
                listaContabilidade2.add(new Contabilidade(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
        

        listaContabilidade2.get(0).actionCompra(preco, finalQuant);
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar informaçao de contabilidade">
        IO gravarContabilidade = new IO(diretorio + "/CSV/contabilidade.csv");
        
        try{
            String info1 = listaContabilidade2.get(0).getLucro()
                    + ";" + listaContabilidade2.get(0).getTotalGasto()
                    + ";" + listaContabilidade2.get(0).getNetWorth()
                    + ";" + listaContabilidade2.get(0).getTotalSalarios()
                    + "\n";
            gravarContabilidade.guardarEstado(info1, 1, "contabilidade.csv", false);
        }
        catch(Exception tR){System.out.println(tR);}
        jTextField6.setText(String.valueOf(listaContabilidade2.get(0).getNetWorth()));
        jTextField7.setText(String.valueOf(listaContabilidade2.get(0).getTotalGasto()));
        jTextField8.setText(String.valueOf(listaContabilidade2.get(0).getTotalSalarios()));
        jTextField9.setText(String.valueOf(listaContabilidade2.get(0).getLucro()));
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar Stock inicial para as tabelas.">
        IO ficheiroMeds = new IO(diretorio + "/CSV/stock.csv");     
        List<String> carregarMedicamentos = ficheiroMeds.carregarEstado();
        DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel();
        
        try{
            for(int i = 0; i < carregarMedicamentos.size(); i++){
                boolean test = false;
                String[] temp = carregarMedicamentos.get(i).split(";");
                for(int k = 0; k < model2.getRowCount(); k++)
                {
                    if(model2.getValueAt(k, 0).equals(temp[1])){
                        test = true;
                    }
                }
                if(test == false){
                    model2.addRow(new Object[]{temp[1], temp[2], temp[4]});  
                }
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
    }//GEN-LAST:event_jBInvConfActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        String medicamento = (String) jTable2.getValueAt(jTable2.getSelectedRow(), 0); 
        int novaQuant = Integer.parseInt(jTextField14.getText());
        int finalQuant = 0;
        float preco = 0;
        float totalPreco;
       
        // <editor-fold defaultstate="collapsed" desc="Load de Stock.csv para a lista listaStock">
        String diretorio = System.getProperty("user.dir");
        IO carregarStock = new IO(diretorio + "/CSV/stock.csv");        
        List<Medicamentos> listaStock = new java.util.ArrayList<Medicamentos>();
        List<String> toLoad = carregarStock.carregarEstado();
        
        try{
            for(int i = 0; i < toLoad.size() - 1; i++){        
                String[] temp = toLoad.get(i).split(";");
                
                listaStock.add(new Medicamentos(temp));
                }
        }
        catch(Exception tR){ tR.printStackTrace();}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Adicionar Stock">
        for(int i = 0; i < listaStock.size(); i++){
            if(listaStock.get(i).getNomeItem().equals(medicamento)){
                listaStock.get(i).adicionarItem(novaQuant);
                finalQuant += listaStock.get(i).getQuantItem();
                preco += listaStock.get(i).getValorItem();
            }
        }
        
        
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar informação da contabilidade">
        IO ficheiroContabilidade2 = new IO(diretorio + "/CSV/contabilidade.csv");       
        List<String> carregarContabilidade2 = ficheiroContabilidade2.carregarEstado();
        List<Contabilidade> listaContabilidade2 = new java.util.ArrayList<Contabilidade>();
        try{
            for(int i = 0; i < carregarContabilidade2.size() - 1; i++){
                String[] temp = carregarContabilidade2.get(i).split(";");
                listaContabilidade2.add(new Contabilidade(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
       

        listaContabilidade2.get(0).actionCompra(preco, novaQuant);
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar informaçao de contabilidade">
        IO gravarContabilidade = new IO(diretorio + "/CSV/contabilidade.csv");
        
        try{
            String info = listaContabilidade2.get(0).getLucro()
                    + ";" + listaContabilidade2.get(0).getTotalGasto()
                    + ";" + listaContabilidade2.get(0).getNetWorth()
                    + ";" + listaContabilidade2.get(0).getTotalSalarios()
                    + "\n";
            gravarContabilidade.guardarEstado(info, 1, "contabilidade.csv", false);
        }
        catch(Exception tR){System.out.println(tR);}
        jTextField6.setText(String.valueOf(listaContabilidade2.get(0).getNetWorth()));
        jTextField7.setText(String.valueOf(listaContabilidade2.get(0).getTotalGasto()));
        jTextField8.setText(String.valueOf(listaContabilidade2.get(0).getTotalSalarios()));
        jTextField9.setText(String.valueOf(listaContabilidade2.get(0).getLucro()));
        // </editor-fold>
         
        // <editor-fold defaultstate="collapsed" desc="Gravacao do stock">
       
        IO gravarStock = new IO(diretorio + "/CSV/stock.csv");
        String info = "";
        int lines = 0;
        for(int i = 0; i < listaStock.size(); i++){
            String temp = listaStock.get(i).getmID() + ";" 
                        + listaStock.get(i).getNomeItem() + ";" 
                        + listaStock.get(i).getDescItem() + ";"
                        + listaStock.get(i).getValorItem() + ";"
                        + listaStock.get(i).getQuantItem() + "\n";
            info += temp;
            lines += 1;
        }
        gravarStock.guardarEstado(info, lines, "stock.csv", false);
        // </editor-fold>    
        
        // <editor-fold defaultstate="collapsed" desc="Carregar Stock inicial para as tabelas.">
        
        IO ficheiroMeds = new IO(diretorio + "/CSV/stock.csv");     
        List<String> carregarMedicamentos = ficheiroMeds.carregarEstado();
        DefaultTableModel model2 = (DefaultTableModel) jTable2.getModel();
        try{
            model2.setRowCount(0);
            for(int k = 0; k < carregarMedicamentos.size() - 1; k++)
            {
                String[] temp = carregarMedicamentos.get(k).split(";");
                model2.addRow(new Object[]{temp[1], temp[2], temp[4]});
                
               
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        
        
        // <editor-fold defaultstate="collapsed" desc="Carregar a lista de Empregados">
        int totalSalarios = 0;
        String diretorio = System.getProperty("user.dir");
        IO ficheiroEmpregados = new IO(diretorio + "/CSV/empregados.csv");       
        List<String> carregarEmpregados = ficheiroEmpregados.carregarEstado();
        List<Pessoa> listaPessoa = new java.util.ArrayList<Pessoa>();
        
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        try{
            for(int i = 0; i < carregarEmpregados.size() - 1; i++){
                String[] temp = carregarEmpregados.get(i).split(";");
                listaPessoa.add(new Pessoa(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
       
        int x = 0;
        // <editor-fold defaultstate="collapsed" desc="Fazer modificaçoes necessarias">
        for(int i = 0; i < jTable1.getRowCount(); i++){
            
            String nomeComp = (String) model.getValueAt(i, 1);
            String[] nomeCompArr = nomeComp.split(" ");
            
            String pNome = nomeCompArr[0];
            String uNome = nomeCompArr[1];
            listaPessoa.get(i).setPnome(pNome);
            listaPessoa.get(i).setUnome(uNome);
            String stringIdade = model.getValueAt(i, 2).toString();
            String stringRank = model.getValueAt(i, 3).toString();
            int Idade = Integer.parseInt(stringIdade);
            int Rank = Integer.parseInt(stringRank);
            
            listaPessoa.get(i).setIdade(Idade);
            listaPessoa.get(i).setRank(Rank);
            listaPessoa.get(i).setEstado(model.getValueAt(i, 6).toString());
        }
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravaçao do novo empregado no ficheiro csv correspondente">
        IO gravarEmpregado = new IO(diretorio + "/CSV/empregados.csv");
        try{
            String info = "";
            int lines = 0;
            for(int k = 0; k < listaPessoa.size(); k++){              
                String temp = listaPessoa.get(k).getPnome() + ";" 
                        + listaPessoa.get(k).getUnome() + ";" 
                        + listaPessoa.get(k).getEstado() + ";"
                        + listaPessoa.get(k).getIdade() + ";" 
                        + listaPessoa.get(k).getRank() + ";" 
                        + listaPessoa.get(k).getID() + "\n";
                info += temp;
                lines += 1;
            }
            gravarEmpregado.guardarEstado(info, 1, "empregados.csv", false);
        }
        catch(Exception tR){System.out.println("Rank tem de ser entre 1 e 4");} 
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar a lista de Empregados de novo">
        IO ficheiroEmpregados2 = new IO(diretorio + "/CSV/empregados.csv");       
        List<String> carregarEmpregados2 = ficheiroEmpregados2.carregarEstado();
        List<Pessoa> listaPessoa2 = new java.util.ArrayList<Pessoa>();
        DefaultTableModel model2 = (DefaultTableModel) jTable1.getModel();
        model2.setRowCount(0);
        try{
            for(int i = 0; i < carregarEmpregados2.size(); i++){
                String[] temp = carregarEmpregados2.get(i).split(";");
                listaPessoa2.add(new Pessoa(temp));
                model2.addRow(new Object[]{listaPessoa2.get(i).getID(), 
                    listaPessoa2.get(i).getPnome() + " " + listaPessoa2.get(i).getUnome(), 
                    listaPessoa2.get(i).getIdade(),
                    listaPessoa2.get(i).getRank(),
                    listaPessoa2.get(i).getPosicao(), 
                    listaPessoa2.get(i).getSalario(),
                    listaPessoa2.get(i).getEstado()});  
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold> 
    }//GEN-LAST:event_jButton10ActionPerformed

    private void PessoalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PessoalFocusGained
        jCriar.setVisible(false);
    }//GEN-LAST:event_PessoalFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Gestao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Gestao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Gestao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Gestao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Gestao().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Contabilidade;
    private javax.swing.JTabbedPane Core;
    private javax.swing.JPanel Itens;
    private javax.swing.JPanel Pessoal;
    private javax.swing.JButton jBCancEmp;
    private javax.swing.JButton jBCriarEmp;
    private javax.swing.JButton jBInvCanc;
    private javax.swing.JButton jBInvConf;
    private javax.swing.JButton jBNProduto;
    private javax.swing.JButton jBPesCriar;
    private javax.swing.JButton jBPesListar;
    private javax.swing.JButton jBStock;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JPanel jCriar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jLista;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jNProduto;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel jStock;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
