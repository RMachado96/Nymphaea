package Visual;

import Classes.IO;
import Classes.Pessoa;
import Classes.Contabilidade;
import Classes.Medicamentos;
import java.util.List;
import javax.swing.table.*;


//
//
//THIS IS THE MAIN BUILD
//
//
public class Loja extends javax.swing.JFrame {
    // <editor-fold defaultstate="collapsed" desc="Metodo de inicializacao.">
    public Loja(){
        
        initComponents();
        this.setLocationRelativeTo(null);
        
        //string diretorio permite que o programa utilize sempre o diretório do próprio projeto
        //independentemente da localizaçao deste
        String diretorio = System.getProperty("user.dir");
        
        // <editor-fold defaultstate="collapsed" desc="Visibilidade dos varios elementos do GUI.">
        
        //todos os botoes/tabelas/etc tem de ser postos a .setVisible(false) ao inicio do programa
        jTextField1.setVisible(true);
        jTextField2.setVisible(true);
        jTextField3.setVisible(true);
        jTextField4.setVisible(true);
        jComboBox1.setVisible(true);
        jLVendaSucesso.setVisible(false);
        jLTotal.setVisible(false);
        // </editor-fold>
    
        // <editor-fold defaultstate="collapsed" desc="Carregar a lista de Pessoal empregado">
        IO startupLoadPessoas = new IO(diretorio + "/CSV/empregados.csv");        
        List<Pessoa> listaPessoa = new java.util.ArrayList<Pessoa>();         
        List<String> toLoad = startupLoadPessoas.carregarEstado();
        try{
            for(int i = 0; i < toLoad.size() - 1; i++){        
                String[] temp = toLoad.get(i).split(";");
                listaPessoa.add(new Pessoa(temp));    
            }
        }
        catch(Exception tR){ tR.printStackTrace();}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Adicionar empregados ao Dropdown Menu.">
        for(int i = 0; i < listaPessoa.size(); i++){   
            //Neste caso, iremos primeiro utilizar um Boleano para verificar se o empregado ja existe na tabela.
            String cnome = listaPessoa.get(i).getPnome() + " " + listaPessoa.get(i).getID();
            boolean verificacao = false; // verificaçao false = nao existe // true = existe
            for(int k = 0; k < jComboBox1.getItemCount();k++){
                if(cnome.equals(jComboBox1.getItemAt(k))){
                    verificacao = true;
                }
            }
            if(verificacao == false){
                jComboBox1.addItem(cnome);
            }
        }
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar Stock inicial para as tabelas.">
        IO ficheiroMeds = new IO(diretorio + "/CSV/stock.csv");       
        List<String> carregarMedicamentos = ficheiroMeds.carregarEstado();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        try{
            for(int i = 0; i < carregarMedicamentos.size(); i++){
                String[] temp = carregarMedicamentos.get(i).split(";");
                model.addRow(new Object[]{temp[1], temp[4], temp[3]});  
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
        
        //Validação da interface
        this.validate();
    }
    // </editor-fold>
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField4 = new javax.swing.JTextField();
        jLTotal = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLVendaSucesso = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setPreferredSize(new java.awt.Dimension(760, 523));

        jLabel1.setText("Primeiro nome");

        jLabel2.setText("NIF");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {}));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel3.setText("Farmacêutico");

        jButton1.setText("Finalizar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setText("Apelido");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel6.setText("Registar Venda");

        jLabel5.setText("Nome do Medicamento");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome do Medicamento", "Quantidade", "Preço"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setAutoscrolls(false);
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jTextField4.setText("1");

        jLTotal.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLTotal.setText(".");

        jLabel7.setText("Quantidade");

        jLVendaSucesso.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLVendaSucesso.setText("Venda efetuada com sucesso!");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 199, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(47, 47, 47)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(215, 215, 215))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel4)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3))
                            .addGap(17, 17, 17)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(212, 212, 212)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(211, 211, 211)
                        .addComponent(jLVendaSucesso))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(77, 77, 77))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLVendaSucesso, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        jMenu1.setText("Menu");

        jMenuItem2.setText("Menu Principal");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Sair");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        this.dispose();
        new Inicio().setVisible(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jComboBox1ActionPerformed
    {//GEN-HEADEREND:event_jComboBox1ActionPerformed
        //System.out.print(jComboBox1.getSelectedIndex());
    }//GEN-LAST:event_jComboBox1ActionPerformed

    // <editor-fold defaultstate="collapsed" desc="Butão "Finalizar".">
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // <editor-fold defaultstate="collapsed" desc="Inicializaçao de variaveis.">
        this.setLocationRelativeTo(null); 
        
        int sIndex = jComboBox1.getSelectedIndex();
        String conteudo = jComboBox1.getItemAt(sIndex);
        String[] splitConteudo = conteudo.split(" ");
        int quant = Integer.parseInt(jTextField4.getText());
        String rowNome = (String)jTable1.getValueAt(jTable1.getSelectedRow(), 0);
        String stringPreco = (String) jTable1.getValueAt(jTable1.getSelectedRow(), 2);
        
        float preco = Float.parseFloat(stringPreco);
        float precoTotal = quant * preco;
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar a nova venda no historico">
        try{
            
            String novaVenda = jTextField1.getText() + ";" 
                    + jTextField2.getText() + ";" 
                    + jTextField3.getText() + ";" 
                    + splitConteudo[0] + ";" + splitConteudo[1] + ";"
                    + quant + ";"
                    + precoTotal
                    + "\n" ;
            String diretorio = System.getProperty("user.dir");
            IO guardarVenda = new IO(diretorio + "/CSV/vendas.csv");
            guardarVenda.guardarEstado(novaVenda, 1, "vendas.csv", true);
            
            jLVendaSucesso.setVisible(true);
            jLTotal.setText("Valor a Pagar: " + precoTotal + "€");
            jLTotal.setVisible(true);
            
            jTextField1.setText("");
            jTextField2.setText("");
            jTextField3.setText("");
            jTextField4.setText("");
            jComboBox1.setSelectedIndex(0);   
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Load, editar quantidades e voltar a gravar.">
        // <editor-fold defaultstate="collapsed" desc="Load de Stock.csv para a lista listaStock">
        String diretorio = System.getProperty("user.dir");
        IO carregarStock = new IO(diretorio + "/CSV/stock.csv");
                
        List<Medicamentos> listaStock = new java.util.ArrayList<Medicamentos>();
                
        List<String> toLoad = carregarStock.carregarEstado();
                
       
        try{
            for(int i = 0; i < toLoad.size() - 1; i++){        
                String[] temp = toLoad.get(i).split(";");
                listaStock.add(new Medicamentos(temp));
                }
        }
        catch(Exception tR){ tR.printStackTrace();}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Subtraçao do stock vendido ao clinte da lista">
        for(int i = 0; i < listaStock.size(); i++){
            if(listaStock.get(i).getNomeItem().equals(rowNome)){
                listaStock.get(i).eliminarItem(quant);
            }
        }
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravaçao da lista agora atualizada">
        
        IO gravarStock = new IO(diretorio + "/CSV/stock.csv");
        String info = "";
        int lines = 0;
        try{
            for(int i = 0; i < listaStock.size(); i++){              
                String temp = listaStock.get(i).getmID() 
                        + ";" + listaStock.get(i).getNomeItem()
                        + ";" + listaStock.get(i).getDescItem() 
                        + ";" + listaStock.get(i).getValorItem()
                        + ";" + listaStock.get(i).getQuantItem() + "\n";
                info += temp;
                lines += 1;
            }
            gravarStock.guardarEstado(info, lines, "stock.csv", false);
        }
        catch(Exception tR){System.out.println("Rank tem de ser entre 1 e 4");}
        // </editor-fold>
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar informação da contabilidade">
        IO ficheiroContabilidade2 = new IO(diretorio + "/CSV/contabilidade.csv");       
        List<String> carregarContabilidade2 = ficheiroContabilidade2.carregarEstado();
        List<Contabilidade> listaContabilidade2 = new java.util.ArrayList<Contabilidade>();
        try{
            for(int i = 0; i < carregarContabilidade2.size() - 1; i++){
                String[] temp = carregarContabilidade2.get(i).split(";");
                listaContabilidade2.add(new Contabilidade(temp));
            }
        }
        catch(Exception e){System.out.println(e);}
        

        listaContabilidade2.get(0).actionVenda(preco, quant);
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Gravar informaçao da contablididade atualizada">
        IO gravarContabilidade = new IO(diretorio + "/CSV/contabilidade.csv");
        
        try{
            String info1 = listaContabilidade2.get(0).getLucro()
                    + ";" + listaContabilidade2.get(0).getTotalGasto()
                    + ";" + listaContabilidade2.get(0).getNetWorth()
                    + ";" + listaContabilidade2.get(0).getTotalSalarios()
                    + "\n";
            gravarContabilidade.guardarEstado(info1, 1, "contabilidade.csv", false);
        }
        catch(Exception tR){System.out.println(tR);}
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Carregar Stock inicial para as tabelas.">
        
        IO ficheiroMeds = new IO(diretorio + "/CSV/stock.csv");       
        List<String> carregarMedicamentos = ficheiroMeds.carregarEstado();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        try{
            for(int i = 0; i < carregarMedicamentos.size(); i++){
                String[] temp = carregarMedicamentos.get(i).split(";");
                model.addRow(new Object[]{temp[1], temp[4], temp[3]});  
            }
        }
        catch(Exception e){System.out.println(e);}
        // </editor-fold>
        
    }//GEN-LAST:event_jButton1ActionPerformed
    // </editor-fold>
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jComboBox1.setSelectedIndex(0);
        jLVendaSucesso.setVisible(false);
        jLTotal.setVisible(false);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(Loja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(Loja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(Loja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(Loja.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Loja().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLTotal;
    private javax.swing.JLabel jLVendaSucesso;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
